const express = require('express');
const sql = require('mssql');
const bcrypt = require('bcrypt');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');

const app = express();
app.use(cors());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Configuración de la conexión a SQL Server Management Studio (SSMS)
const dbConfig = {
    server: 'DESKTOP-5HUIJKE\\SQLEXPRESS', // Nombre del servidor obtenido de la imagen
    database: 'WorldnewsDB',              // Nombre de tu base de datos
    options: {
        encrypt: false,                   // Evita errores de certificados en entorno local
        trustServerCertificate: true,     // Confía en el certificado del servidor
        trustedConnection: true           // Utiliza la Autenticación de Windows configurada
    }
};

// 1. Ruta para Registrar Usuario (Sign In / Register)
app.post('/api/register', async (req, res) => {
    const { username, password, email } = req.body;
    try {
        let pool = await sql.connect(dbConfig);
        
        // Encriptar la contraseña por seguridad
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        // Insertar en la tabla Usuarios
        await pool.request()
            .input('username', sql.VarChar, username)
            .input('password_hash', sql.VarChar, hashedPassword)
            .input('email', sql.VarChar, email)
            .query('INSERT INTO Usuarios (username, password_hash, email) VALUES (@username, @password_hash, @email)');

        res.status(201).json({ message: 'Usuario registrado con éxito' });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: 'Error al registrar el usuario' });
    }
});

// 2. Ruta para Iniciar Sesión (Log In)
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    try {
        let pool = await sql.connect(dbConfig);
        
        let result = await pool.request()
            .input('username', sql.VarChar, username)
            .query('SELECT * FROM Usuarios WHERE username = @username');

        if (result.recordset.length === 0) {
            return res.status(400).json({ error: 'Usuario o contraseña incorrectos' });
        }

        const user = result.recordset[0];

        // Comparar la contraseña ingresada con el hash de la base de datos
        const match = await bcrypt.compare(password, user.password_hash);
        if (!match) {
            return res.status(400).json({ error: 'Usuario o contraseña incorrectos' });
        }

        res.status(200).json({ message: 'Login exitoso', username: user.username });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: 'Error en el servidor' });
    }
});

// 3. Ruta para Crear un Artículo (Admin) - Sin fotos ni enlaces
app.post('/api/articles', async (req, res) => {
    const { title, content, author } = req.body;
    try {
        let pool = await sql.connect(dbConfig);
        
        await pool.request()
            .input('title', sql.VarChar, title)
            .input('content', sql.Text, content)
            .input('author', sql.VarChar, author)
            .query('INSERT INTO Articulos (title, content, author) VALUES (@title, @content, @author)');

        res.status(201).json({ message: 'Artículo creado con éxito' });
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: 'Error al crear el artículo' });
    }
});

// 4. Ruta para Obtener Todos los Artículos (Para el Feed de Noticias)
app.get('/api/articles', async (req, res) => {
    try {
        let pool = await sql.connect(dbConfig);
        let result = await pool.request().query('SELECT * FROM Articulos ORDER BY created_at DESC');
        
        res.status(200).json(result.recordset);
    } catch (err) {
        console.log(err);
        res.status(500).json({ error: 'Error al obtener los artículos' });
    }
});

// Iniciar servidor
const PORT = 3000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en http://localhost:${PORT}`);
});