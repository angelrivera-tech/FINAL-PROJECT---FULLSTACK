const { sql, connectDB } = require('../config/db');
const bcrypt = require('bcrypt');

// Register User Controller
const registerUser = async (req, res) => {
    const { username, password, email } = req.body;
    try {
        let pool = await connectDB();
        
        // Encrypt the password securely
        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        // Insert into Users table
        await pool.request()
            .input('username', sql.VarChar, username)
            .input('password_hash', sql.VarChar, hashedPassword)
            .input('email', sql.VarChar, email)
            .query('INSERT INTO Usuarios (username, password_hash, email) VALUES (@username, @password_hash, @email)');

        res.status(201).json({ message: 'Usuario registrado con éxito' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error al registrar el usuario' });
    }
};

// Login User Controller
const loginUser = async (req, res) => {
    const { username, password } = req.body;
    try {
        let pool = await connectDB();
        
        let result = await pool.request()
            .input('username', sql.VarChar, username)
            .query('SELECT * FROM Usuarios WHERE username = @username');

        if (result.recordset.length === 0) {
            return res.status(400).json({ error: 'Usuario o contraseña incorrectos' });
        }

        const user = result.recordset[0];

        // Compare entered password with database hash
        const match = await bcrypt.compare(password, user.password_hash);
        if (!match) {
            return res.status(400).json({ error: 'Usuario o contraseña incorrectos' });
        }

        res.status(200).json({ message: 'Login exitoso', username: user.username });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error en el servidor' });
    }
};

module.exports = {
    registerUser,
    loginUser
};